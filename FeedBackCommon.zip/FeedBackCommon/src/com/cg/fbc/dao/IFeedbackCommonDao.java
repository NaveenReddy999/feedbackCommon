package com.cg.fbc.dao;

import com.cg.fbc.dto.FeedbackCommon;

public interface IFeedbackCommonDao {
	public void addFeedback(FeedbackCommon fb);
}
