package com.cg.fbc.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.fbc.dto.FeedbackCommon;

@Repository("feedbackdao")
public class FeedbackCommonDaoImpl implements IFeedbackCommonDao {

	@PersistenceContext
	EntityManager em;
	@Override
	public void addFeedback(FeedbackCommon fb) {
		
		em.persist(fb);
		em.flush();
		
	}
	

}
