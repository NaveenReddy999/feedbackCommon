package com.cg.fbc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;


import org.springframework.web.bind.annotation.RequestMethod;
import com.cg.fbc.dto.FeedbackCommon;
import com.cg.fbc.service.IFeedbackCommonService;

@Controller
public class FeedbackCommonController {
	@Autowired
	IFeedbackCommonService feedbackservice;
	
	@RequestMapping(value="/home")
	public String getFeedback(@ModelAttribute("my") FeedbackCommon fb ) {
	
		return "addfeedback";	 
	}
	@RequestMapping(value="addfeed", method=RequestMethod.POST )
	public String addFeedbackData(@ModelAttribute("my") FeedbackCommon fb){
	
	feedbackservice.addFeedback(fb);
		return "Success";
	}
	

}
