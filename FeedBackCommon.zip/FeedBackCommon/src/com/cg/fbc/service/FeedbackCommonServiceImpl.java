package com.cg.fbc.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fbc.dao.IFeedbackCommonDao;
import com.cg.fbc.dto.FeedbackCommon;

@Service("feedbackservice")
@Transactional
public class FeedbackCommonServiceImpl implements IFeedbackCommonService{
	@Autowired
	IFeedbackCommonDao feedbackdao;

	@Override
	public void addFeedback(FeedbackCommon fb) {
		
		feedbackdao.addFeedback(fb);
	}

}
