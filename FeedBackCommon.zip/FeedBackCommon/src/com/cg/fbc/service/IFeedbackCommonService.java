package com.cg.fbc.service;

import com.cg.fbc.dto.FeedbackCommon;

public interface IFeedbackCommonService {

	public void addFeedback(FeedbackCommon fb);
}
