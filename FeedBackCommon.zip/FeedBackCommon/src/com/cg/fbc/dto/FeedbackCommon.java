package com.cg.fbc.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="FeedbacksCommon")
public class FeedbackCommon {
	
	@Column(name="Product_id")
	private int productId;
	@Id
	@Column(name="User_id")
	private int userId;
	
	@Column(name="Feedback")
	private String feedback;

	public FeedbackCommon() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FeedbackCommon(int productId, int userId, String feedback) {
		super();
		this.productId = productId;
		this.userId = userId;
		this.feedback = feedback;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	@Override
	public String toString() {
		return "FeedbackCommon [productId=" + productId + ", userId=" + userId
				+ ", feedback=" + feedback + "]";
	}


}
